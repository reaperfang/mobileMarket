module.exports = {
	NODE_ENV: '"production"',
	ENV_CONFIG: '"prod"',
	DATA_API: '"/data_server"',
	WEBSOCKET_server:'"ws://127.0.0.1:9000"',
	staticHost: 'https://test-m-aiyouyi.yun300.cn/',
	UPLOAD_SERVER:'"/upload_server"',
	UPLOAD_COUPON_SERVER:'"/upload_server"'
}
