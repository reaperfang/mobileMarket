module.exports = {
	NODE_ENV: '"testing"',
  ENV_CONFIG: '"test"',
  DATA_API: '"/data-server"',
  WEBSOCKET_server:'"ws://127.0.0.1:9000"',
  staticHost: 'https://test-m-aiyouyi.yun300.cn/',
  UPLOAD_SERVER:'"/upload_server"',
  UPLOAD_COUPON_SERVER:'"/upload_coupon_server"'
}
