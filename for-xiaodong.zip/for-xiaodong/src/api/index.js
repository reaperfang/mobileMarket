import * as demo from "./demo"; //订单接口demo
import * as demo2 from "./demo2"; //商铺接口demo
import * as websocketDemo from "./websocketDemo"; //websocket测试demo
import * as login from "./login"; //登录接口demo

export default {
	demo,
	demo2,
	websocketDemo,
	login
};
