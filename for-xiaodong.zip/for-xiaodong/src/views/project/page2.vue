<template>
  <p>项目页面2</p>
</template>

<script>
export default {
  name: 'page2',
  data () {
    return {
    }
  },
}
</script>
<style lang="scss" scoped>
</style>
