<template>
  <p>项目页面1</p>
</template>

<script>
export default {
  name: 'page1',
  data () {
    return {
    }
  },
}
</script>
<style lang="scss" scoped>
</style>
